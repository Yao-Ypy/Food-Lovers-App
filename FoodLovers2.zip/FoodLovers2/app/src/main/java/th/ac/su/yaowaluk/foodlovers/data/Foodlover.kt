package th.ac.su.yaowaluk.foodlovers.data

data class Foodlover(
    val imageFile: String,
    val monsterName: String,
    val caption: String,
    val description: String,
    val price: Int,
    val scariness: Int

)