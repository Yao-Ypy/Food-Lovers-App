package th.ac.su.yaowaluk.foodlovers

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_main.*
import th.ac.su.yaowaluk.foodlovers.Utils.getJsonDataFromAsset
import th.ac.su.yaowaluk.foodlovers.data.Foodlover
import th.ac.su.yaowaluk.foodlovers.data.FoodloversAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        var itemList: java.util.ArrayList<Foodlover> = java.util.ArrayList<Foodlover>()
        lateinit var arrayAdapter: ArrayAdapter<Foodlover>


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val jsonFileString = getJsonDataFromAsset(applicationContext,"foodlove_data.json")

        val gson = Gson()
        val listItemType = object  : TypeToken<ArrayList<Foodlover>>(){}.type

        var foodloveList : ArrayList<Foodlover> = gson.fromJson(jsonFileString,listItemType)

        itemList = foodloveList
        val adapter = FoodloversAdapter(this@MainActivity,itemList)

        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->

            var intent = Intent(this@MainActivity,DetailActivity::class.java)


            intent.putExtra("title",itemList[position].monsterName)
            intent.putExtra("caption",itemList[position].caption)
            intent.putExtra("imageFile",itemList[position].imageFile)
            intent.putExtra("description",itemList[position].description)
            intent.putExtra("star",itemList[position].scariness)



            startActivity(intent)
        }


    }
}